# Agentrix SaaS Landing Kit | FREE v1.0

**Two editable frontend landing-page templates, free for personal and commercial use. No payment, password, account, or subscription.**

## What's inside

- `templates/atlas/index.html` — Atlas Analytics, a dark graphite / bright green analytics SaaS landing demo.
- `templates/fieldnote/index.html` — Fieldnote CRM, an editorial light/lavender CRM SaaS landing demo.
- `docs/launch-checklist.md` — a quick implementation and release checklist.
- `LICENSE.txt` — Agentrix Free Use License v1.0: commercial use permitted; redistribution as a competing raw template pack is not.
- `SHA256SUMS.txt` — file checksums for release verification.

## Start in two minutes

1. Extract the ZIP into a folder. **No password needed.**
2. Open `templates/atlas/index.html` or `templates/fieldnote/index.html` in Chrome, Edge, Firefox, Safari or another modern browser.
3. Edit the HTML directly with a text editor. The CSS and JavaScript are embedded in each HTML file. No dependencies or installation.
4. Replace all example brands, plan prices, sample dashboards, links, CTA destinations and statements with real details from your project.
5. Upload the edited HTML to your own static HTTPS host, then test all flows on the deployed site.

## What this is *not*

These are **frontend templates**, not actual SaaS applications. They do NOT provide a real account system, payment collection, lead capture, CRM, subscription backend, database, web hosting, support SLA or analytics service. The illustrated brands, UI dashboards and price examples are fictional. Demo interactions (responsive mobile menu, FAQ, example price toggle, downloadable starter brief) work in the browser; connect actual services yourself as needed.

## Release and quality

The HTML source was checked for external network calls / remote runtime dependencies, and the package was checked for completeness and integrity. Tests do not replace your own browser, accessibility, privacy, security or deployment checks. The package includes no Stripe connection or paid checkout. Opening the example HTML files does not send data to Agentrix.

## Free-use license

Use, customize and deploy for personal and commercial client projects at no charge. Do **not** sell or redistribute this same raw source pack as a competing template product. See `LICENSE.txt` for the complete terms. This is source-available, not MIT or open-source. The other five Agentrix free CLI tools are separately licensed under MIT.

Project: https://github.com/pauloflp/Agentrix/tree/main/premium/agentrix-saas-landing-kit
